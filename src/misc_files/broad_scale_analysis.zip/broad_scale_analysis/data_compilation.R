library(dplyr)
library(tibble)
library(ggplot2)
library(lme4)
library(lmerTest)
library(bbmle) #AIC tests
library(lubridate)
library(car) #Anova() function
library(multcomp) #posthoc tests for ANOVA type III effects

#change list to names of your directories
dir = as.list(c("cbma_acoustic_metrics","kiowa_acoustic_metrics","lwma_acoustic_metrics","sswma_aru_acoustic_metrics"))


bio = lapply(dir, function(x){
  setwd(paste0("C:/Users/meely/OneDrive - University of Oklahoma/University of Oklahoma/Ross Lab/Aridity and Song Attenuation/Sound Analysis/data_clean/",x,sep=""))
  site = substr(x,1,4) #change substring length to what your site names are
  bio_files = list.files(pattern = "bio") %>%
    lapply(read.csv) %>%
    bind_rows() %>%
    add_column(site = site)
})

bio_all_sites = rbind(bio[[1]],bio[[2]],bio[[3]],bio[[4]])
write.csv(bio_all_sites,"bio_all_sites.csv", row.names = FALSE)


# Dataframe Editing -------------------------------------------------------
aci_all_sites = read.csv("C:/Users/meely/OneDrive - University of Oklahoma/University of Oklahoma/Ross Lab/Aridity and Song Attenuation/Sound Analysis/data_clean/aci_all_sites.csv", header = TRUE)

aci_all_sites$site = recode_factor(aci_all_sites$site, lwma = "lwma", kiow = "kiowa", cbma = "cbma", sswm = "sswma")

aci_all_sites$site = factor(aci_all_sites$site, levels=c("lwma","sswma","cbma","kiowa"))
aci_all_sites$dew_temp = aci_all_sites$temperature-((100-aci_all_sites$relh)/5)
aci_all_sites$date_time_utc = as_datetime(aci_all_sites$obs_time, tz = "UTC")

# Correct Kiowa Times on 06/17 and 06/18 --------------------------------------------
kiowa_bad = aci_all_sites %>%
  filter(site == "kiowa") %>%
  filter(date == "2021-06-17"| date == "2021-06-18") %>%
  filter(aru == "aru03")

aci_minus = anti_join(aci_all_sites,kiowa_bad)

kiowa_bad$date_time_utc = kiowa_bad$date_time_utc-3600 #minus 1 hour or 3600s
aci_all_sites = rbind(aci_minus,kiowa_bad)

aci_all_sites$time_utc = hms::as_hms(substr(aci_all_sites$date_time_utc,12,19))
aci_all_sites$week = week(aci_all_sites$date_time_utc)


# Adding Water Station Data and Switching Dates ---------------------------



ggplot(data = aci_all_sites,
       aes(x = dew_temp, y = left_channel,color = site)) +
  geom_line()

# aci_all_sites$date_time3 = ifelse(aci_all_sites$site == "kiowa", as_datetime(aci_all_sites$date_time, tz="America/Denver"), as_datetime(aci_all_sites$date_time, tz="America/Chicago"))

# aci_all_sites$date_time_utc = as_datetime(aci_all_sites$date_time3, tz = "UTC")
# aci_all_sites$time_utc = hms::as_hms(substr(aci_all_sites$date_time_utc,12,19))

m0 = lm(left_channel ~ 1, data = aci_all_sites)
m1 = lm(left_channel ~ site, data = aci_all_sites)
m2 = lm(left_channel ~ site * temperature, data = aci_all_sites)
m3 = lm(left_channel ~ site * date_time_utc, data = aci_all_sites)
m4 = lm(left_channel ~ site * relh, data = aci_all_sites)
m5 = lm(left_channel ~ site * dew_temp * date_time_utc, data = aci_all_sites)
m6 = lm(left_channel ~ site * relh * date_time_utc, data = aci_all_sites)
AICctab(m0,m1,m2,m3,m4,m5,m6, nobs = 9207, base=TRUE,delta=TRUE, sort=TRUE, weights=TRUE)


summary(m5)
summary(m6)
# aci_all_sites$SHD = interaction(scale(aci_all_sites$time_utc),aci_all_sites$dew_temp)
# m5.5 = lmer(left_channel ~ SHD + (1|site), data = aci_all_sites, REML = FALSE)
summary(m1)
Anova(m1, type ="III")
contrasts = glht(m1, linfct = mcp(site = "Tukey"))
summary(contrasts)

AICctab(m0,m1,m2,m3,m4,m5, nobs = 9207, base=TRUE,delta=TRUE, sort=TRUE, weights=TRUE)

summary(m5)
Anova(m1, type = "III")
# m5 = lm(left_channel ~ SHD, data = aci_all_sites)
# aci_all_sites$SHD = interaction(scale(aci_all_sites$time_utc),aci_all_sites$relh,aci_all_sites$site)

aci_means = aci_all_sites %>%
  filter(is.na(left_channel) == FALSE) %>%
  group_by(site,week) %>%
  summarize(aciMean = mean(left_channel),
            mean_temp = mean(temperature),
            mean_relh = mean(relh),
            mean_dew = mean(dew_temp))


# Means across time -------------------------------------------------------
###Relative Humidity
ggplot(data = aci_means,aes(x =week, y = aciMean, color=mean_relh)) +
  geom_point(size = 5, aes(shape = site))+
  scale_shape_manual(name = "Site", labels = c("LWMA", "SSWMA", "CBMA", "KIOWA"), values = c(15,16,17,18))+
  geom_line(aes(group = site))+
  scale_color_viridis_c(name = "Relative\nHumidity %",direction = -1)+
  # scale_x_time(name = "Time (CDT)", labels = c("05:00:00", "07:00:00", "09:00:00", "11:00:00", "13:00:00")) +
  scale_x_continuous(name = "Week", labels = c("May", "June", "July", "August"))+
  scale_y_continuous(name = "acidiversity Index"
                     # , limits = c(0,0.5)
                     )+
  theme_classic(base_size = 20) +
  theme(axis.title.y = element_text(angle = 90, vjust = 0.5))
setwd("C:/Users/meely/OneDrive - University of Oklahoma/University of Oklahoma/Ross Lab/Aridity and Song Attenuation/Sound Analysis/results")
ggsave("aci_acoustic_metric_time.jpg", dpi=300, height=6, width=12, units="in")

###Dewpoint Temperature
ggplot(data = aci_means,aes(x =week, y = aciMean, color=mean_dew)) +
  geom_point(size = 5, aes(shape = site))+
  scale_shape_manual(name = "Site", labels = c("LWMA", "SSWMA", "CBMA", "KIOWA"), values = c(15,16,17,18))+
  geom_line(aes(group = site))+
  scale_color_viridis_c(name = "Dewpoint\nTemperature (°C)",direction = -1)+
  # scale_x_time(name = "Time (CDT)", labels = c("05:00:00", "07:00:00", "09:00:00", "11:00:00", "13:00:00")) +
  scale_x_continuous(name = "Month", labels = c("May", "June", "July", "August"))+
  scale_y_continuous(name = "Acoustic Complexity Index"
                     # , limits = c(0,0.5)
  )+
  theme_classic(base_size = 20) +
  theme(axis.title.y = element_text(angle = 90, vjust = 0.5))
setwd("C:/Users/meely/OneDrive - University of Oklahoma/University of Oklahoma/Ross Lab/Aridity and Song Attenuation/Sound Analysis/results")
ggsave("aci_acoustic_metric_week_dew.jpg", dpi=300, height=6, width=12, units="in")
# Facet Wrap --------------------------------------------------------------
ggplot(data = aci_means,aes(x =mean_relh, y = aciMean)) +
  geom_point(size = 5, aes(shape = site))+
  scale_shape_manual(name = "Site", labels = c("LWMA", "SSWMA", "CBMA", "KIOWA"), values = c(15,16,17,18))+
  # scale_color_viridis_c(name = "Dewpoint\nTemperature(C) %",direction = -1)+
  # scale_x_time(name = "Time (UTC)", labels = c("05:00:00", "07:00:00", "09:00:00", "11:00:00", "13:00:00")) +
  scale_y_continuous(name = "acidiversity Index")+
  facet_grid(rows = vars(site)) +
  theme_classic(base_size = 20) +
  theme(axis.title.y = element_text(angle = 90, vjust = 0.5))
setwd("C:/Users/meely/OneDrive - University of Oklahoma/University of Oklahoma/Ross Lab/Aridity and Song Attenuation/Sound Analysis/results")
ggsave("aci_acoustic_metric_time.jpg", dpi=300, height=6, width=12, units="in")


# Mean bar graph ----------------------------------------------------------
ggplot(data = aci_means,
       aes(x = time_utc, y = aciMean, fill = site))+
  geom_bar(stat = "identity", position=position_dodge())


# Acoustic Indices across Full 2 months -----------------------------------
aci_means = aci_all_sites %>%
#   filter(is.na(left_channel) == FALSE) %>%
  group_by(site,date_time_utc) %>%
  summarize(aciMean = mean(left_channel),
            mean_temp = mean(temperature),
            mean_relh = mean(relh),
            mean_dew = mean(dew_temp))

ggplot(data = aci_means,
       aes(x = date_time_utc, y = aciMean, color=mean_relh)) +
  geom_point(size = 2, aes(shape = site))+
  geom_line(aes(group = site))+
  # facet_wrap(~site) +
  # scale_colour_continuous(labels = c(60,70,80,90))
  scale_color_viridis_c(name = "Relh",direction = -1)+
  theme_classic(base_size = 20) +
  theme(axis.title.y = element_text(angle = 90, vjust = 0.5))


# Weather Graphs ----------------------------------------------------------

ggplot(data = aci_means,
       aes(x = date_time_utc, y = mean_temp, color= site)) +
  geom_line()

ggplot(data = aci_means,
       aes(x = date_time_utc, y = mean_relh, color= site)) +
  geom_line()
# # Uploading Data ----------------------------------------------------------
# aci_files = list.files(pattern = "aci") %>%
#   lapply(read.csv) %>%
#   bind_rows
# 
# aci_means = aci_files %>%
#   group_by(temperature,obs_time) %>%
#   summarize(aciMean = mean(left_channel))
# 
# adi_files = list.files(pattern = "adi") %>%
#   lapply(read.csv) %>%
#   bind_rows
# 
# adi_means = adi_files %>%
#   group_by(temperature,obs_time) %>%
#   summarize(adiMean = mean(left_channel))
# 
# aei_files = list.files(pattern = "aei") %>%
#   lapply(read.csv) %>%
#   bind_rows
# 
# aei_means = aei_files %>%
#   group_by(temperature,obs_time) %>%
#   summarize(aeiMean = mean(left_channel))
# 
# bio_files = list.files(pattern = "bio") %>%
#   lapply(read.csv) %>%
#   bind_rows
# 
