library(soundecology) #obtain broad scale acoustic metrics
library(tuneR) #loading and reading sound files
library(seewave) #soundwave analysis
library(osfr) #downloading files from osf
library(dplyr) #data management and conversion
library(lubridate) #convert date types
library(lme4) #linear mixed models
library(lmerTest)
library(okmesonet)
library(ggplot2) #create good graphs
library(extrafont)
library(lsmeans)
library(pbapply)

#Set so you know which computer you are using; your personal computer or the OK Biosurvey computer
computer = 0
if(computer == 0){
  m = "meely"
} else {
  m = "meelyn.pandit"
}

aru = c("aru01","aru02","aru03","aru04","aru05") #create list of directories that the sound analysis code will be applied to
# aru = c("ws01","ws02",ws03","ws04","ws05","ws06","ws07","ws08","ws09","ws10""ws11","ws12","ws13","ws14","ws15")
# aru = c("wg01","wg02","wg03","wg04","wg05")

aru_list = as.list(aru) #make the directories a list
setwd("D:/") #set working directory, this is the working directory on the harddrive with all the stored aru recordings.

# Load Weather data -------------------------------------------------------

load("sitka_weather_data.Rdata")


# Run Apply function to obtain Acoustic Indices ---------------------------
pblapply(aru_list, function(x){
  #Acoustic Complexity Index - measures overall acoustic distinctiveness in recordings, biophonies and geophonies based on variability and length of sound intensity
  results = paste0(x, "_aci_results.csv") #create a csv file to write results to
  #multiple_sounds function is used to analyze multiple sounds at once. you specify which index you want with "soundindex"
  multiple_sounds(directory = x, resultfile = results, soundindex = "acoustic_complexity",min_freq = 1000, max_freq = 8000, no_cores = "max")  
  aci_results = read.csv(results, header = TRUE) #upload the results file into R so we can add more variables to the datafile
  names(aci_results) = c("filename","sampling_rate","bit","duration","channels","index","fft_w","min_freq","max_freq", "j", "left_channel","right_channel") #renaming columns
  aci_results$aru = substr(x, 1,5) #obtain aru number from the directory name, you may need to change the length of the substring based on your directory name
  aci_results$year = as.factor((substr(aci_results$filename, 1,4))) #obtain year from AudioMoth recording filename
  aci_results$month = as.factor((substr(aci_results$filename,5,6))) #obtain month from AudioMoth recording filename
  aci_results$day = as.factor((substr(aci_results$filename, 7,8))) #obtain day from AudioMoth recording filename
  aci_results$hour = as.factor(substr(aci_results$filename, 10,11)) #obtain hour from AudioMoth recording filename
  aci_results$min = as.factor(substr(aci_results$filename, 12,13)) #obtain minute from AudioMoth recording filename
  aci_results$second = as.factor(substr(aci_results$filename, 14,15)) #obtain seconds from AudioMoth recording filename
  aci_results$date = as.character(paste0(aci_results$year,"-",aci_results$month,"-",aci_results$day)) #combine year, month, and day to get date
  aci_results$time = as.character(paste0(aci_results$hour,":",aci_results$min,":",aci_results$second)) #combine hour, minute, and seconds to get time
  aci_results$date_time = as.POSIXct(as.character(paste0(aci_results$date," ", aci_results$time), format = "%Y-%m-%d %H:%M:%S"))#create datetime variable
  aci_results_df = as.data.frame(aci_results) #convert results into a dataframe
  aci_results2 = merge(aci_results_df, weather_data, by.x = "date_time", by.y = "local_time") #merge your aci_dataset with the weather_data based on date_time in the aci_results dataframe and the local_time in the weather_data dataframe
  
  write.csv(aci_results2, file = paste0("aci_results_processed_",aci_results2$aru[1],".csv", sep = ""),row.names = FALSE) #save the dataframe as a new csv file
  
  # #Acoustic Diversity Index
  results2 = paste0(x, "_adi_results.csv")
  multiple_sounds(directory = x, resultfile = results2, soundindex = "acoustic_diversity",max_freq = 8000, no_cores = "max")
  adi_results <- read.csv(results2, header = TRUE)
  names(adi_results) = c("filename","sampling_rate","bit","duration","channels","index","max_freq","db_threshold","freq_steps", "left_channel","right_channel")
  adi_results$aru = x
  adi_results$year = as.factor((substr(adi_results$filename, 1,4)))
  adi_results$month = as.factor((substr(adi_results$filename,5,6)))
  adi_results$day = as.factor((substr(adi_results$filename, 7,8)))
  adi_results$hour = as.factor(substr(adi_results$filename, 10,11))
  adi_results$min = as.factor(substr(adi_results$filename, 12,13))
  adi_results$second = as.factor(substr(adi_results$filename, 14,15))
  adi_results$date = as.character(paste0(adi_results$year,"-",adi_results$month,"-",adi_results$day))
  adi_results$time = as.character(paste0(adi_results$hour,":",adi_results$min,":",adi_results$second))
  adi_results$date_time = as.POSIXct(as.character(paste0(adi_results$date," ",adi_results$time),format = "%Y-%m-%d %H:%M:%S"))
  adi_results_df = as.data.frame(adi_results)
  adi_results2 = merge(adi_results_df, sswma_data, by.x = "date_time", by.y = "local_time")
  write.csv(adi_results2, file = paste0("adi_results_processed_",adi_results2$aru[1],".csv", sep = ""),row.names = FALSE)
  
  ##Acoustic Eveness Index
    results3 = paste0(x, "_aei_results.csv")
    multiple_sounds(directory = x, resultfile = results3, soundindex = "acoustic_evenness",max_freq = 8000, no_cores = "max")
    aei_results <- read.csv(results3, header = TRUE)
    names(aei_results) = c("filename","sampling_rate","bit","duration","channels","index","max_freq", "db_threshold", "freq_steps", "left_channel","right_channel")
    aei_results$aru = x
    aei_results$year = as.factor((substr(aei_results$filename, 1,4)))
    aei_results$month = as.factor((substr(aei_results$filename,5,6)))
    aei_results$day = as.factor((substr(aei_results$filename, 7,8)))
    aei_results$hour = as.factor(substr(aei_results$filename, 10,11))
    aei_results$min = as.factor(substr(aei_results$filename, 12,13))
    aei_results$second = as.factor(substr(aei_results$filename, 14,15))
    aei_results$date = as.character(paste0(aei_results$year,"-",aei_results$month,"-",aei_results$day))
    aei_results$time = as.character(paste0(aei_results$hour,":",aei_results$min,":",aei_results$second))
    aei_results$date_time = as.POSIXct(as.character(paste0(aei_results$date," ", aei_results$time), format = "%Y-%m-%d %H:%M:%S"))# 
    aei_results_df = as.data.frame(aei_results)
    aei_results2 = merge(aei_results_df, sswma_data, by.x = "date_time", by.y = "local_time")
    write.csv(aei_results2,
              file = paste0("aei_results_processed_",aei_results2$aru[1],".csv", sep = ""),
              row.names = FALSE)
  
    # Biology Acoustic Dataset Labelling --------------------------------------
    results4 = paste0(x, "_bio_results.csv")
    multiple_sounds(directory = x, resultfile = results4, soundindex = "bioacoustic_index",max_freq = 8000, no_cores = "max")
    bio_results = read.csv(results4, header = TRUE)
    names(bio_results) = c("filename","sampling_rate","bit","duration","channels","index","fft_w","min_freq","max_freq", "left_channel","right_channel")
    bio_results$aru = x
    bio_results$year = as.factor((substr(bio_results$filename, 1,4)))
    bio_results$month = as.factor((substr(bio_results$filename,5,6)))
    bio_results$day = as.factor((substr(bio_results$filename, 7,8)))
    bio_results$hour = as.factor(substr(bio_results$filename, 10,11))
    bio_results$min = as.factor(substr(bio_results$filename, 12,13))
    bio_results$second = as.factor(substr(bio_results$filename, 14,15))
    bio_results$date = as.character(paste0(bio_results$year,"-",bio_results$month,"-",bio_results$day))
    bio_results$time = as.character(paste0(bio_results$hour,":",bio_results$min,":",bio_results$second))
    bio_results$date_time = as.POSIXct(as.character(paste0(bio_results$date," ", bio_results$time), format = "%Y-%m-%d %H:%M:%S"))
    bio_results_df = as.data.frame(bio_results)
    bio_results2 = merge(bio_results_df, sswma_data, by.x = "date_time", by.y = "local_time")
    write.csv(bio_results2,
              file = paste0("bio_results_processed_",bio_results2$aru[1],".csv", sep = ""),
              row.names = FALSE)
  })
  
